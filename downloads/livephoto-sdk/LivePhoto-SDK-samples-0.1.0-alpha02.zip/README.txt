Synthetic SDK samples, NOT OEM camera originals or gallery certification.
