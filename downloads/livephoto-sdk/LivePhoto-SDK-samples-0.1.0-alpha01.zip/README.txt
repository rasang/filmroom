Synthetic SDK packaging samples; NOT OEM camera originals and NOT gallery compatibility certification.
